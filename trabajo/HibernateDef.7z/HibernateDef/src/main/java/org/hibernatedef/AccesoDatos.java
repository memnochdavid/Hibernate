package org.hibernatedef;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Collection;
import java.util.List;


public class AccesoDatos {

    public void CrearUsuario(String nombre, String pass, String tipo) {
        Transaction tx;
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        tx = sesion.beginTransaction();

        UsuariosClass nuevo = new UsuariosClass(nombre, pass, tipo);
        sesion.save(nuevo);

        tx.commit();
        sesion.close();
    }

    public String mostrarAdmins() {
        String res = "";
        Session sesion = HibernateUtil.getSessionFactory().openSession();

        String consulta = "from UsuariosClass u where u.tipo='admin'";
        Query sentencia = sesion.createQuery(consulta);
        List<UsuariosClass> lista_usuarios = sentencia.list();

        for (UsuariosClass objeto_usuario : lista_usuarios) {
            //if(objeto_usuario.getTipo().equals("admin")){
            res += objeto_usuario.getLogin() + "\n";
            res += objeto_usuario.getPass() + "\n";
            //}
        }

        sesion.close();

        return res;
    }

    public void modificarAdmins() {
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = sesion.beginTransaction();
        String consulta = "from UsuariosClass u where u.tipo='admin'";
        Query sentencia = sesion.createQuery(consulta);
        List<UsuariosClass> lista_usuarios = sentencia.list();

        for (UsuariosClass objeto_usuario : lista_usuarios) {
            objeto_usuario.setPass("984234");
        }
        tx.commit();
        sesion.close();

    }

    public String recuperarUsuario(String user) {
        String res = "";
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        String consulta = "from UsuariosClass u where u.login='"+user+"'";
        Query sentencia = sesion.createQuery(consulta);
        UsuariosClass objeto_usuario = (UsuariosClass) sentencia.uniqueResult();

        res+=objeto_usuario.getLogin()+"\n"
            + objeto_usuario.getPass()+"\n"
            + objeto_usuario.getTipo()+"\n";


        sesion.close();
        return res;
    }

    public String empleadosDepartamento(String dep) {
        String res = "";

        Session sesion = HibernateUtil.getSessionFactory().openSession();
        String consulta = "from Departamento d where d.nombre='" + dep + "'";

        Query sentencia = sesion.createQuery(consulta);
        Departamento objeto_departamento = (DepartamentosClass) sentencia.uniqueResult();

        Collection<Empleado> empleados = objeto_departamento.getEmpleadosById();

        for (EmpleadosClass objeto_empleado : empleados) {
            res += objeto_empleado.getApellido() + "\n"
                    + objeto_empleado.getCargo() + "\n"
                    + objeto_empleado.getSalario() + "\n"
                    + objeto_empleado.getDepartamentosByDepartamento().getNombre() + "\n"
                    + objeto_empleado.getDepartamentosByDepartamento().getLocalizacion() + "\n";
        }
        sesion.close();

        return res;
    }

    public String infoEmpleado(String apellido) {
        String res = "";

        Session sesion = HibernateUtil.getSessionFactory().openSession();
        String consulta = "from EmpleadosClass e where e.apellido='" + apellido + "'";

        Query sentencia = sesion.createQuery(consulta);
        EmpleadosClass objeto_empleado = (EmpleadosClass) sentencia.uniqueResult();

        res += "DEPARTAMENTO:" + objeto_empleado.getDepartamentosByDepartamento().getNombre() + "\n";
        if (objeto_empleado.getEmpleadosByJefe() != null) {
            res += "JEFE:" + objeto_empleado.getEmpleadosByJefe().getApellido() + "\n";
        }

        res += "SUBORDINADOS:\n";
        Collection<EmpleadosClass> subordinados = objeto_empleado.getEmpleadosById();
        for (EmpleadosClass e : subordinados) {
            res += e.getApellido() + "\n";
        }

        return res;
    }
}
